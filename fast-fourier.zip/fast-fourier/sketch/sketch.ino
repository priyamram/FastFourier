// Fast Fourier: card reader sketch for the UNO Q's STM32 side.
// Reads an RC522 RFID/NFC card and sends its ID to the Linux side,
// where app.py looks the card up in config.json.
//
// Wiring (RC522 -> UNO Q):  SDA/SS -> D10, SCK -> D13, MOSI -> D11,
//                           MISO -> D12, RST -> D9, 3.3V -> 3.3V, GND -> GND
// The RC522 is a 3.3 V part: do not connect it to 5 V.
//
// Libraries: MFRC522 (by GithubCommunity) and Arduino_RouterBridge.

#include <SPI.h>
#include <MFRC522.h>
#include <Arduino_RouterBridge.h>

const uint8_t SS_PIN = 10;
const uint8_t RST_PIN = 9;
const unsigned long REPEAT_MS = 3000;  // ignore the same card held on the reader

MFRC522 rfid(SS_PIN, RST_PIN);
String lastUid = "";
unsigned long lastTapMs = 0;

void setup() {
  Bridge.begin();
  SPI.begin();
  rfid.PCD_Init();
}

void loop() {
  if (!rfid.PICC_IsNewCardPresent() || !rfid.PICC_ReadCardSerial()) {
    delay(50);
    return;
  }

  String uid = "";
  for (byte i = 0; i < rfid.uid.size; i++) {
    if (rfid.uid.uidByte[i] < 0x10) uid += "0";
    uid += String(rfid.uid.uidByte[i], HEX);
  }
  uid.toUpperCase();

  unsigned long now = millis();
  if (uid != lastUid || now - lastTapMs > REPEAT_MS) {
    Bridge.notify("card_tapped", uid);
    lastUid = uid;
    lastTapMs = now;
  }

  rfid.PICC_HaltA();
  rfid.PCD_StopCrypto1();
}
