"""Simple technical signals (moving averages + RSI) for a stock.

These describe recent price behaviour. They are not a forecast, and the
dashboard labels them that way. This is the place to plug in a trained
scikit-learn model later.
"""


def sma(values, n):
    return sum(values[-n:]) / n if len(values) >= n else None


def rsi(closes, period=14):
    if len(closes) < period + 1:
        return None
    changes = [b - a for a, b in zip(closes, closes[1:])]
    gains = [max(c, 0) for c in changes]
    losses = [max(-c, 0) for c in changes]
    avg_g = sum(gains[:period]) / period
    avg_l = sum(losses[:period]) / period
    for g, l in zip(gains[period:], losses[period:]):
        avg_g = (avg_g * (period - 1) + g) / period
        avg_l = (avg_l * (period - 1) + l) / period
    if avg_l == 0:
        return 100.0
    return 100 - 100 / (1 + avg_g / avg_l)


def analyze(bars, price=None):
    closes = [float(b["c"]) for b in bars]
    if not closes:
        return {"trend": "No data", "summary": "No recent price history for this symbol."}
    last = float(price) if price else closes[-1]
    s20, s50, r = sma(closes, 20), sma(closes, 50), rsi(closes)
    change_20d = (last / closes[-21] - 1) if len(closes) > 20 else None

    if s20 is None or s50 is None:
        trend = "Not enough history"
    elif last > s20 > s50:
        trend = "Uptrend"
    elif last < s20 < s50:
        trend = "Downtrend"
    else:
        trend = "Sideways"

    if r is None:
        momentum = ""
    elif r >= 70:
        momentum = "RSI is above 70: the price has run up fast (overbought)."
    elif r <= 30:
        momentum = "RSI is below 30: the price has fallen fast (oversold)."
    else:
        momentum = "RSI is in the normal range."

    parts = [f"{trend}."]
    if change_20d is not None:
        parts.append(f"{change_20d:+.1%} over the last 20 trading days.")
    if momentum:
        parts.append(momentum)
    return {
        "trend": trend,
        "sma20": round(s20, 2) if s20 else None,
        "sma50": round(s50, 2) if s50 else None,
        "rsi": round(r, 1) if r is not None else None,
        "change_20d": change_20d,
        "summary": " ".join(parts),
    }
