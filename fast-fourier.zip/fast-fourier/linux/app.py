#!/usr/bin/env python3
"""Fast Fourier terminal.

Tap a card -> unlock that person's Alpaca paper account -> see their
Portfolio Score, holdings and signals, and buy/sell from the touchscreen.

Run:  python3 app.py     then open http://<board-ip>:8080
"""
import json
import os
import re
import sys
import threading
import time
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs

import requests

import card_reader
from alpaca_client import AlpacaClient, AlpacaError
from scoring import score_portfolio
from signals import analyze

try:  # Autopilot needs numpy:  sudo apt install python3-numpy
    import autopilot as autopilot_mod
    AUTOPILOT_ERROR = None
except ImportError:
    autopilot_mod = None
    AUTOPILOT_ERROR = "Autopilot needs numpy. On the board run: sudo apt install python3-numpy"

HERE = os.path.dirname(os.path.abspath(__file__))
CONFIG_PATH = os.path.join(HERE, "config.json")
INDEX_PATH = os.path.join(HERE, "web", "index.html")
SYMBOL_RE = re.compile(r"^[A-Z]{1,5}(\.[A-Z])?$")
SCORE_CACHE_SECONDS = 60


def normalize_uid(uid):
    return re.sub(r"[^0-9A-Za-z-]", "", str(uid)).upper()


def load_config():
    if not os.path.exists(CONFIG_PATH):
        sys.exit("config.json not found. Copy config.example.json to config.json "
                 "and add your card ID and Alpaca paper keys.")
    with open(CONFIG_PATH) as f:
        cfg = json.load(f)
    cfg.setdefault("host", "0.0.0.0")
    cfg.setdefault("port", 8080)
    cfg.setdefault("lock_after_seconds", 300)
    cfg.setdefault("dev_mode", True)
    cfg.setdefault("max_order_qty", 1000)
    cfg.setdefault("autopilot", {})
    cfg["autopilot"].setdefault("stop_on_lock", True)
    cfg["cards"] = {normalize_uid(k): v for k, v in cfg.get("cards", {}).items()}
    return cfg


class Session:
    """Who is unlocked right now. One person at a time, like an ATM."""

    def __init__(self, cfg):
        self.cfg = cfg
        self.lock = threading.Lock()
        self.autopilot = None
        self._clear()
        self.unknown_uid = None

    def _clear(self):
        self.uid = self.name = self.client = None
        self.last_activity = 0
        self.score_cache = (0, None)
        if self.autopilot and self.cfg["autopilot"]["stop_on_lock"]:
            self.autopilot.stop()
            self.autopilot = None

    def tap(self, raw_uid):
        uid = normalize_uid(raw_uid)
        card = self.cfg["cards"].get(uid)
        with self.lock:
            if not card:
                self.unknown_uid = uid
                print(f"Unknown card: {uid}  (add it to config.json to link an account)")
                return False
            if self.uid == uid and self.client:  # same card again: stay unlocked
                self.last_activity = time.time()
                return True
            if self.autopilot and self.autopilot.owner != uid:
                self.autopilot.stop()  # different person: never trade their account
                self.autopilot = None
            self._clear()
            self.uid, self.name = uid, card.get("name", "Trader")
            self.client = (self.autopilot.client if self.autopilot
                           else AlpacaClient(card["key"], card["secret"]))
            self.last_activity = time.time()
            self.unknown_uid = None
        print(f"Unlocked for {self.name}")
        return True

    def lock_now(self):
        with self.lock:
            self._clear()

    def touch(self):
        with self.lock:
            if self.client:
                self.last_activity = time.time()

    def active_client(self):
        with self.lock:
            idle = time.time() - self.last_activity
            if self.client and idle > self.cfg["lock_after_seconds"]:
                print("Locked after inactivity.")
                self._clear()
            return self.client


SESSION = None


# ---- actions -----------------------------------------------------------
def compute_score(client):
    account = client.account()
    positions = client.positions()
    hist = client.portfolio_history("3M", "1D")
    equity_by_date = {}
    for ts, eq in zip(hist.get("timestamp") or [], hist.get("equity") or []):
        if eq is not None and eq > 0:
            day = datetime.fromtimestamp(ts, tz=timezone.utc).date().isoformat()
            equity_by_date[day] = float(eq)
    spy_by_date = {b["t"][:10]: float(b["c"]) for b in client.daily_bars("SPY", days=120)}
    return score_portfolio(account, positions, equity_by_date, spy_by_date)


def dashboard(client):
    account = client.account()
    positions = client.positions()
    orders = client.open_orders()
    clock = client.clock()

    cached_at, score = SESSION.score_cache
    if score is None or time.time() - cached_at > SCORE_CACHE_SECONDS:
        try:
            score = compute_score(client)
        except (AlpacaError, requests.RequestException) as e:
            score = {"error": str(e)}
        SESSION.score_cache = (time.time(), score)

    return {
        "name": SESSION.name,
        "account": {k: account.get(k) for k in
                    ("equity", "last_equity", "cash", "buying_power", "status")},
        "market_open": clock.get("is_open"),
        "next_open": clock.get("next_open"),
        "positions": [{k: p.get(k) for k in
                       ("symbol", "qty", "avg_entry_price", "current_price",
                        "market_value", "unrealized_pl", "unrealized_plpc")}
                      for p in positions],
        "orders": [{k: o.get(k) for k in
                    ("id", "symbol", "side", "qty", "status", "submitted_at")}
                   for o in orders],
        "score": score,
    }


def clean_symbol(raw):
    symbol = str(raw or "").strip().upper()
    if not SYMBOL_RE.match(symbol):
        raise ValueError("Enter a stock symbol like AAPL or MSFT.")
    return symbol


def quote(client, symbol):
    symbol = clean_symbol(symbol)
    price = client.latest_price(symbol)
    bars = client.daily_bars(symbol, days=150)
    if price is None and not bars:
        raise ValueError(f"No market data found for {symbol}.")
    return {"symbol": symbol, "price": price or bars[-1]["c"],
            "signal": analyze(bars, price)}


def place_order(client, body):
    symbol = clean_symbol(body.get("symbol"))
    side = body.get("side")
    if side not in ("buy", "sell"):
        raise ValueError("Side must be buy or sell.")
    try:
        qty = int(body.get("qty"))
    except (TypeError, ValueError):
        raise ValueError("Quantity must be a whole number.")
    if not 1 <= qty <= SESSION.cfg["max_order_qty"]:
        raise ValueError(f"Quantity must be between 1 and {SESSION.cfg['max_order_qty']}.")

    asset = client.asset(symbol)
    if not asset.get("tradable"):
        raise ValueError(f"{symbol} can't be traded on Alpaca.")
    if side == "sell":  # no short selling from the terminal
        held = sum(float(p["qty"]) for p in client.positions() if p["symbol"] == symbol)
        if qty > held:
            raise ValueError(f"You hold {held:g} shares of {symbol}, so you can sell at most that many.")

    order = client.submit_market_order(symbol, qty, side)
    SESSION.score_cache = (0, None)
    print(f"Order: {side} {qty} {symbol} -> {order.get('status')}")
    return {"id": order.get("id"), "status": order.get("status"),
            "symbol": symbol, "qty": qty, "side": side}


def autopilot_status(client):
    if SESSION.autopilot:
        return SESSION.autopilot.status()
    return {"available": autopilot_mod is not None, "state": "off", "dry_run": True,
            "error": AUTOPILOT_ERROR, "model": None, "radar": [], "log": []}


def autopilot_control(client, body):
    if autopilot_mod is None:
        raise ValueError(AUTOPILOT_ERROR)
    action = body.get("action")
    if action == "start":
        if not SESSION.autopilot:
            SESSION.autopilot = autopilot_mod.Autopilot(client, SESSION.cfg["autopilot"], SESSION.uid)
        SESSION.autopilot.start(dry_run=bool(body.get("dry_run", True)))
    elif action == "stop":
        if SESSION.autopilot:
            SESSION.autopilot.stop()
    else:
        raise ValueError("Unknown autopilot action.")
    SESSION.score_cache = (0, None)
    return autopilot_status(client)


# ---- HTTP --------------------------------------------------------------
class Handler(BaseHTTPRequestHandler):
    server_version = "FastFourier/1.0"

    def log_message(self, fmt, *args):
        pass  # keep the terminal readable

    def _send(self, code, body, ctype="application/json"):
        data = body if isinstance(body, bytes) else json.dumps(body).encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def _body(self):
        length = int(self.headers.get("Content-Length") or 0)
        if length > 10_000:
            raise ValueError("Request too large.")
        return json.loads(self.rfile.read(length) or b"{}")

    def _authed(self, fn, *args, touch=False):
        client = SESSION.active_client()
        if not client:
            return self._send(401, {"error": "locked"})
        if touch:
            SESSION.touch()
        try:
            return self._send(200, fn(client, *args))
        except ValueError as e:
            return self._send(400, {"error": str(e)})
        except AlpacaError as e:
            return self._send(502, {"error": str(e)})
        except requests.RequestException:
            return self._send(502, {"error": "Can't reach Alpaca. Check the board's internet connection."})

    def do_GET(self):
        path, _, query = self.path.partition("?")
        if path in ("/", "/index.html"):
            with open(INDEX_PATH, "rb") as f:
                return self._send(200, f.read(), "text/html; charset=utf-8")
        if path == "/api/state":
            client = SESSION.active_client()
            return self._send(200, {
                "unlocked": client is not None,
                "name": SESSION.name,
                "unknown_uid": SESSION.unknown_uid,
                "dev_mode": SESSION.cfg["dev_mode"],
                "card_mode": card_reader.mode(),
            })
        if path == "/api/dashboard":
            return self._authed(dashboard)
        if path == "/api/autopilot":
            return self._authed(autopilot_status)
        if path == "/api/quote":
            symbol = parse_qs(query).get("symbol", [""])[0]
            return self._authed(quote, symbol, touch=True)
        self._send(404, {"error": "Not found"})

    def do_POST(self):
        try:
            body = self._body()
        except ValueError:
            return self._send(400, {"error": "Invalid request body."})
        if self.path == "/api/order":
            return self._authed(place_order, body, touch=True)
        if self.path == "/api/autopilot":
            return self._authed(autopilot_control, body, touch=True)
        if self.path == "/api/cancel":
            return self._authed(lambda c: c.cancel_order(str(body.get("id"))) or {"ok": True}, touch=True)
        if self.path == "/api/ping":
            SESSION.touch()
            return self._send(200, {"ok": True})
        if self.path == "/api/lock":
            SESSION.lock_now()
            return self._send(200, {"ok": True})
        if self.path == "/api/dev/tap" and SESSION.cfg["dev_mode"]:
            ok = SESSION.tap(body.get("uid", ""))
            return self._send(200 if ok else 403, {"ok": ok})
        self._send(404, {"error": "Not found"})


def main():
    global SESSION
    cfg = load_config()
    SESSION = Session(cfg)
    server = ThreadingHTTPServer((cfg["host"], cfg["port"]), Handler)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    print(f"Fast Fourier running: open http://<board-ip>:{cfg['port']} "
          f"(find the IP with: hostname -I)")
    print(f"{len(cfg['cards'])} card(s) linked. Paper trading only.")
    try:
        card_reader.run(SESSION.tap)
    except KeyboardInterrupt:
        print("\nStopped.")
        server.shutdown()


if __name__ == "__main__":
    main()
