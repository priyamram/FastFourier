"""Receives card taps and passes the card ID to the app.

Two modes:
- bridge:   running as an Arduino App Lab app, the STM32 sketch sends
            Bridge.notify("card_tapped", uid) and this file receives it.
- terminal: running with plain `python3 app.py` over SSH, type a card ID
            and press Enter to simulate a tap.
"""
import time

try:
    from arduino.app_utils import App, Bridge  # only exists inside App Lab
except ImportError:
    App = Bridge = None


def mode():
    return "bridge" if Bridge else "terminal"


def run(on_tap):
    """Blocks forever, calling on_tap(uid) for every tap."""
    if Bridge:
        Bridge.provide("card_tapped", lambda uid: on_tap(str(uid)))
        print("Card reader: listening for taps from the STM32 sketch.")
        App.run()
        return

    print("Card reader: terminal mode. Type a card ID and press Enter to tap.")
    while True:
        try:
            uid = input().strip()
        except EOFError:  # no keyboard attached (e.g. started in background)
            while True:
                time.sleep(3600)
        if uid:
            on_tap(uid)
