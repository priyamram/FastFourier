"""Fast Fourier Portfolio Score: a 300-850 rating of a stock portfolio's health.

Factor                    Weight  What it measures
Diversification (beta)     35%    Spread across holdings and sectors, market sensitivity
Risk-adjusted return       30%    Sharpe ratio of daily portfolio returns
Drawdown resilience        20%    Largest peak-to-trough drop in account value
Cash / liquidity buffer    15%    Share of the account held in cash

Each factor is scored 0.0-1.0, combined by weight, then mapped onto 300-850.
When there isn't enough history to judge a factor, it gets a neutral 0.5.
"""
import math
import statistics

WEIGHTS = {
    "diversification": 0.35,
    "risk_adjusted_return": 0.30,
    "drawdown": 0.20,
    "liquidity": 0.15,
}

# Sector lookup for common tickers. Anything missing counts as "Other".
SECTORS = {
    "AAPL": "Technology", "MSFT": "Technology", "NVDA": "Technology", "AMD": "Technology",
    "INTC": "Technology", "AVGO": "Technology", "ORCL": "Technology", "CRM": "Technology",
    "ADBE": "Technology", "CSCO": "Technology", "IBM": "Technology", "QCOM": "Technology",
    "GOOGL": "Communication", "GOOG": "Communication", "META": "Communication",
    "NFLX": "Communication", "DIS": "Communication", "T": "Communication", "VZ": "Communication",
    "AMZN": "Consumer", "TSLA": "Consumer", "HD": "Consumer", "MCD": "Consumer",
    "NKE": "Consumer", "SBUX": "Consumer", "F": "Consumer", "GM": "Consumer",
    "WMT": "Staples", "COST": "Staples", "PG": "Staples", "KO": "Staples", "PEP": "Staples",
    "JPM": "Financials", "BAC": "Financials", "WFC": "Financials", "GS": "Financials",
    "V": "Financials", "MA": "Financials", "BRK.B": "Financials",
    "JNJ": "Healthcare", "UNH": "Healthcare", "PFE": "Healthcare", "LLY": "Healthcare",
    "MRK": "Healthcare", "ABBV": "Healthcare",
    "XOM": "Energy", "CVX": "Energy", "COP": "Energy",
    "BA": "Industrials", "CAT": "Industrials", "GE": "Industrials", "UPS": "Industrials",
    "NEE": "Utilities", "DUK": "Utilities",
    "SPY": "Index fund", "VOO": "Index fund", "IVV": "Index fund", "VTI": "Index fund",
    "QQQ": "Index fund", "DIA": "Index fund",
    "BND": "Bonds", "AGG": "Bonds", "TLT": "Bonds",
}
# Broad funds already hold many companies, so one fund counts like ~10 holdings.
FUND_BREADTH = {"SPY": 10, "VOO": 10, "IVV": 10, "VTI": 10, "QQQ": 6, "DIA": 6,
                "BND": 10, "AGG": 10}

RATING_BANDS = [(800, "Exceptional"), (740, "Very good"), (670, "Good"),
                (580, "Fair"), (300, "Needs work")]


def _clamp(x, lo=0.0, hi=1.0):
    return max(lo, min(hi, x))


def _returns(values):
    return [b / a - 1 for a, b in zip(values, values[1:]) if a > 0]


def _beta(equity_by_date, spy_by_date):
    dates = sorted(set(equity_by_date) & set(spy_by_date))
    if len(dates) < 11:
        return None
    port = _returns([equity_by_date[d] for d in dates])
    mkt = _returns([spy_by_date[d] for d in dates])
    n = min(len(port), len(mkt))
    port, mkt = port[-n:], mkt[-n:]
    var_m = statistics.pvariance(mkt)
    if var_m == 0 or statistics.pvariance(port) == 0:
        return None
    mp, mm = statistics.fmean(port), statistics.fmean(mkt)
    cov = sum((a - mp) * (b - mm) for a, b in zip(port, mkt)) / n
    return cov / var_m


def _diversification(positions, equity_by_date, spy_by_date):
    holdings = [(p["symbol"], abs(float(p["market_value"]))) for p in positions]
    holdings = [(s, v) for s, v in holdings if v > 0]
    if not holdings:
        return 0.5, "No stock holdings yet, so this factor is neutral."

    total = sum(v for _, v in holdings)
    weights = {s: v / total for s, v in holdings}
    hhi = sum(w * w / FUND_BREADTH.get(s, 1) for s, w in weights.items())
    effective_n = 1 / hhi
    sectors = {SECTORS.get(s, "Other") for s in weights}
    biggest_sym, biggest_w = max(weights.items(), key=lambda kv: kv[1])

    concentration = _clamp(effective_n / 10)
    sector_spread = _clamp(len(sectors) / 5)
    beta = _beta(equity_by_date, spy_by_date)
    beta_score = 0.5 if beta is None else _clamp(1 - abs(beta - 1))

    score = 0.5 * concentration + 0.3 * sector_spread + 0.2 * beta_score
    if biggest_w > 0.5:
        score *= 0.8  # extra penalty for one dominant position

    detail = (f"{len(weights)} holdings across {len(sectors)} sector(s); "
              f"largest is {biggest_sym} at {biggest_w:.0%}.")
    if beta is not None:
        detail += f" Beta vs. S&P 500: {beta:.2f}."
    return _clamp(score), detail


def _risk_adjusted(values):
    rets = _returns(values)
    if len(rets) < 10:
        return 0.5, "Needs about two weeks of account history; neutral for now."
    sd = statistics.stdev(rets)
    if sd == 0:
        return 0.5, "Account value hasn't moved yet; neutral for now."
    sharpe = statistics.fmean(rets) / sd * math.sqrt(252)
    return _clamp((sharpe + 1) / 3), f"Sharpe ratio {sharpe:.2f} over {len(rets)} trading days."


def _drawdown(values):
    if len(values) < 2:
        return 0.5, "Not enough history yet; neutral for now."
    peak, worst = values[0], 0.0
    for v in values:
        peak = max(peak, v)
        worst = max(worst, (peak - v) / peak if peak > 0 else 0)
    return _clamp(1 - worst / 0.30), f"Largest drop from a peak: {worst:.1%}."


def _liquidity(account):
    equity = float(account.get("equity") or 0)
    cash = float(account.get("cash") or 0)
    if equity <= 0:
        return 0.0, "Account has no equity."
    pct = cash / equity * 100
    if pct < 0:
        score = 0.0
    elif pct < 5:
        score = pct / 5
    elif pct <= 25:
        score = 1.0
    else:  # plenty of safety, but idle cash slowly lowers the score
        score = 1 - 0.5 * (min(pct, 100) - 25) / 75
    return _clamp(score), f"{pct:.0f}% of the account is cash (5-25% scores best)."


def score_portfolio(account, positions, equity_by_date, spy_by_date):
    values = [equity_by_date[d] for d in sorted(equity_by_date)]
    parts = {
        "diversification": ("Diversification", *_diversification(positions, equity_by_date, spy_by_date)),
        "risk_adjusted_return": ("Risk-adjusted return", *_risk_adjusted(values)),
        "drawdown": ("Drawdown resilience", *_drawdown(values)),
        "liquidity": ("Cash buffer", *_liquidity(account)),
    }
    raw = sum(WEIGHTS[k] * parts[k][1] for k in WEIGHTS)
    score = round(300 + 550 * raw)
    rating = next(label for floor, label in RATING_BANDS if score >= floor)
    return {
        "score": score,
        "rating": rating,
        "factors": [
            {"key": k, "name": parts[k][0], "weight": WEIGHTS[k],
             "value": round(parts[k][1] * 100), "detail": parts[k][2]}
            for k in WEIGHTS
        ],
    }
