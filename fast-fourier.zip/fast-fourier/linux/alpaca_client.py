"""Small Alpaca REST client for Fast Fourier.

Trading is locked to the PAPER endpoint on purpose, so this terminal can
never place a real-money order.
"""
from datetime import datetime, timedelta, timezone

import requests

TRADING_URL = "https://paper-api.alpaca.markets/v2"  # paper only, by design
DATA_URL = "https://data.alpaca.markets/v2"
FEED = "iex"  # free market-data feed for paper accounts


class AlpacaError(Exception):
    """Alpaca answered with an error (bad keys, rejected order, etc.)."""


class AlpacaClient:
    def __init__(self, key, secret, timeout=10):
        self.session = requests.Session()
        self.session.headers.update({
            "APCA-API-KEY-ID": key,
            "APCA-API-SECRET-KEY": secret,
            "Accept": "application/json",
        })
        self.timeout = timeout

    def _request(self, method, url, **kwargs):
        resp = self.session.request(method, url, timeout=self.timeout, **kwargs)
        if resp.status_code >= 400:
            try:
                message = resp.json().get("message", resp.text)
            except ValueError:
                message = resp.text.strip()[:200]
            raise AlpacaError(f"Alpaca error {resp.status_code}: {message}")
        if resp.status_code == 204 or not resp.content:
            return None
        return resp.json()

    # ---- account & portfolio -------------------------------------------
    def account(self):
        return self._request("GET", f"{TRADING_URL}/account")

    def positions(self):
        return self._request("GET", f"{TRADING_URL}/positions")

    def portfolio_history(self, period="3M", timeframe="1D"):
        return self._request(
            "GET", f"{TRADING_URL}/account/portfolio/history",
            params={"period": period, "timeframe": timeframe},
        )

    def clock(self):
        return self._request("GET", f"{TRADING_URL}/clock")

    def asset(self, symbol):
        return self._request("GET", f"{TRADING_URL}/assets/{symbol}")

    # ---- orders --------------------------------------------------------
    def open_orders(self, limit=20):
        return self._request(
            "GET", f"{TRADING_URL}/orders",
            params={"status": "open", "limit": limit, "direction": "desc"},
        )

    def submit_market_order(self, symbol, qty, side):
        return self._request("POST", f"{TRADING_URL}/orders", json={
            "symbol": symbol,
            "qty": str(qty),
            "side": side,
            "type": "market",
            "time_in_force": "day",
        })

    def cancel_order(self, order_id):
        return self._request("DELETE", f"{TRADING_URL}/orders/{order_id}")

    # ---- market data ---------------------------------------------------
    def daily_bars(self, symbol, days=150):
        start = (datetime.now(timezone.utc) - timedelta(days=days)).date().isoformat()
        data = self._request(
            "GET", f"{DATA_URL}/stocks/{symbol}/bars",
            params={"timeframe": "1Day", "start": start, "feed": FEED,
                    "limit": 1000, "sort": "asc"},
        )
        return data.get("bars") or []

    def latest_price(self, symbol):
        data = self._request(
            "GET", f"{DATA_URL}/stocks/{symbol}/trades/latest",
            params={"feed": FEED},
        )
        trade = data.get("trade") or {}
        return trade.get("p")
